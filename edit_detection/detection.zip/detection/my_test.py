import os
import time
from PIL import Image
import matplotlib.pyplot as plt
import torch
import torchvision
#data argument module
import torchvision.transforms as T
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
import numpy as np
import cv2

#모델을 로드
def load_model(model_path):
    #모델 정의
    model = torchvision.models.detection.fasterrcnn_resnet50_fpn(pretrained=False)
    num_classes = 3  
    in_features = model.roi_heads.box_predictor.in_features
    model.roi_heads.box_predictor = FastRCNNPredictor(in_channels=in_features, num_classes=num_classes)
    
    #전체 모델 구조 포함 로드
    #model = torch.load(model_path)
    #가중치만 가져올 때
    model.load_state_dict(torch.load(model_path, map_location=torch.device('cuda')))
    model.eval()
    
    return model

def get_prediction(filename, model, threshold, class_list):
    start_time = time.time()
    COCO_INSTANCE_CATEGORY_NAMES = class_list
    img = Image.open(filename)
    transform = T.Compose([T.ToTensor()])
    img = transform(img)
    pred = model([img])
    end_time = time.time()
    pred_class = [COCO_INSTANCE_CATEGORY_NAMES[i] for i in list(pred[0]['labels'].numpy())]
    pred_boxes = [[(i[0], i[1]), (i[2], i[3])] for i in list(pred[0]['boxes'].detach().numpy())]
    pred_score = list(pred[0]['scores'].detach().numpy())
    pred_t = [pred_score.index(x) for x in pred_score if x > threshold][-1]
    pred_boxes = pred_boxes[:pred_t + 1]
    pred_class = pred_class[:pred_t + 1]
    print("Check_predict_time:", end_time - start_time)
    return pred_boxes, pred_class

def object_detection_api(img_path, model, class_list, threshold=0.5, rect_th=3, text_size=3, text_th=3):
    for filename in os.listdir(img_path):      
        if filename.lower().endswith('.jpg'):
            file = os.path.join(img_path, filename)
            boxes, pred_cls = get_prediction(file, model, threshold, class_list)
            img = cv2.imread(file)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            for i in range(len(boxes)):
                cv2.rectangle(img, boxes[i][0], boxes[i][1], color=(0, 255, 0), thickness=rect_th)
                cv2.putText(img, pred_cls[i], boxes[i][0], cv2.FONT_HERSHEY_SIMPLEX, text_size, (0, 255, 0), thickness=text_th)
            plt.figure(figsize=(20, 30))
            plt.imshow(img)
            plt.xticks([])
            plt.yticks([])
            plt.show()

def main(test_path, model_path):
    # 모델 로드
    model = load_model(model_path)
    
    COCO_INSTANCE_CATEGORY_NAMES = [
        '__background__', 'big robot', 'small robot'
    ]
    
    threshold = 0.5
    
    object_detection_api(img_path=test_path, model=model, class_list=COCO_INSTANCE_CATEGORY_NAMES, threshold=threshold)

if __name__ == "__main__":
    test_path = 'D:/pytorch_cuda/detection_data/dataset1/test'
    model_path = 'D:/pytorch_cuda/detection_data/dataset1/output/model.pth'
    main(test_path, model_path)