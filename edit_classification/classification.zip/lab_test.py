import torch

from PIL import Image

import matplotlib.pyplot as plt

import torchvision.transforms as transforms

import numpy as np

import cv2
import time
import os

class_label = ['cat', 'dog']

# load pth model
model = torch.load(r'D:\pytorch_cuda\image_data\dataset1\output\model.pth', weights_only=False)

# set model to inference mode
model.eval()

print(model)

transform = transforms.Compose([      

        transforms.Resize(256),      

        transforms.CenterCrop(224),  

        transforms.ToTensor(),        

        transforms.Normalize(        
        
        mean=[0.485, 0.456, 0.406],  
        
        std=[0.229, 0.224, 0.225])
])

#os 패키지로 호출
test_dir = r"D:\pytorch_cuda\image_data\dataset1\test"
os.chdir(test_dir)
list = os.listdir(test_dir)
file_num = 20
acc_num = 0
all_img = plt.figure()
rows = 4
cols = 5
number = 0
for file in list:
    start_time = time.time()
    print(file)
    test_image = Image.open(file)
    #plt.figure(figsize=(5,5))  

    #plt.imshow(test_image)
    #이미지 호출 확인.
    #plt.show()
    
    img = transform(test_image)
    
    print(img.shape)
    #plt.figure(figsize=(5,5))  
    #plt.imshow(img.permute(1, 2, 0))
    #plt.show()
 
    img = img.to('cuda')
    
    with torch.no_grad():
        pred = model(img.unsqueeze(0))
        
        print(pred)
        
        y_pred = torch.argmax(pred)
        
        print(y_pred)

        print(class_label[y_pred])
        
    using_time = time.time() - start_time
    print(f"using_time : {using_time}")
    
    if 'cat' in file and class_label[y_pred] == 'cat':
        acc_num = acc_num + 1
    elif 'dog' in file and class_label[y_pred] == 'dog':
        acc_num = acc_num + 1
    number += 1
    sub = all_img.add_subplot(rows, cols, number)
    sub.set_title(file)
    sub.imshow(test_image)
    sub.set_xlabel('y_pred : ' + class_label[y_pred])
    sub.set_xticks([]), sub.set_yticks([])
    sub.text(0,100,class_label[y_pred]+':'+f'{pred[0][y_pred]:.3f}',size=15,color='red')
    #plt.xticks([])
    #plt.yticks([])

plt.show()
print(f"right_result : {acc_num}")
print(f'acc : {acc_num / file_num}')