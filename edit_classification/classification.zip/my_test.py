import torch  
from PIL import Image  # 이미지 처리를 위한 Pillow 라이브러리 임포트
import matplotlib.pyplot as plt  
import torchvision.transforms as transforms  # 이미지 변환을 위한 torchvision.transforms 임포트
import torchvision.models as models  
import numpy as np  
import cv2  
import os  # 운영 체제 관련 기능을 위한 os 라이브러리 임포트
import time  

class_label = ['cat', 'dog']  # 클래스 레이블 정의 (예: 고양이, 개)
test_folder = r'D:\pytorch_cuda\code\vision\references\classification\test'  # 테스트 이미지 경로
model_path = r'D:\pytorch_cuda\image_data\dataset1\output\model.pth'  # 모델 파일 경로

# 모델 구조 정의 ResNet50사용
def initialize_model(num_classes, use_pretrained=True):
    weights = models.ResNet50_Weights.IMAGENET1K_V1 if use_pretrained else None
    model_ft = models.resnet50(weights=weights)
    num_ftrs = model_ft.fc.in_features
    model_ft.fc = torch.nn.Linear(num_ftrs, num_classes)  # 출력 레이어 크기 조정 (클래스 개수에 맞게)
    return model_ft

# 클래스 레이블 수에 맞춰 모델 초기화
num_classes = len(class_label)  # 클래스 수 정의 (고양이, 개)
model = initialize_model(num_classes)

# 저장된 가중치 로드
model.load_state_dict(torch.load(model_path))

# 모델을 추론 모드로 설정
model.eval()

# 이미지 변환 정의
transform = transforms.Compose([  # 여러 변환을 조합하여 하나의 변환으로 만듦
    transforms.Resize(256),  # 이미지 크기 조정 (256x256)
    transforms.CenterCrop(224),  # 이미지 중앙을 224x224로 자르기
    transforms.ToTensor(),  # 이미지를 텐서(tensor)로 변환
    transforms.Normalize(  # 텐서 정규화
        mean=[0.485, 0.456, 0.406],  # 평균값
        std=[0.229, 0.224, 0.225]  # 표준편차
    )
])

def load_test_images(folder_path):
    total_correct = 0  # 정확하게 예측한 이미지 수
    total_images = 0  # 총 테스트한 이미지 수

    for filename in os.listdir(folder_path):  # 폴더 내의 모든 파일에 대해 반복
        image_path = os.path.join(folder_path, filename)  # 파일 경로 생성
        test_image = Image.open(image_path)  # 이미지 파일 열기
        plt.figure(figsize=(5, 5))  # 그림 크기 설정
        plt.imshow(test_image)  # 이미지를 화면에 표시
        img = transform(test_image)  # 변환을 테스트 이미지에 적용
        start_time = time.time()  # 추론 시작 시간 기록
        with torch.no_grad():  # 그래디언트 계산 비활성화 (추론 모드)
            pred = model(img.unsqueeze(0))  # 모델에 이미지를 입력하여 예측 수행
            probabilities = torch.nn.functional.softmax(pred, dim=1)  # 소프트맥스 함수 적용하여 확률 계산
            y_pred = torch.argmax(probabilities)  # 가장 높은 확률을 가진 클래스 인덱스 추출
            confidence = probabilities[0][y_pred].item() * 100  # 확률을 백분율로 변환
        end_time = time.time()  # 추론 종료 시간 기록
        # 예측 결과와 시간을 출력
        print(f"Predicted: {class_label[y_pred]}, Confidence: {confidence:.2f}%, Time taken: {end_time - start_time:.4f} seconds")
        # 예측이 맞는지 확인 
        if ('cat' in filename and y_pred == 0) or ('dog' in filename and y_pred == 1):
            total_correct += 1
        total_images += 1
        # 예측 결과를 그림에 표시
        plt.text(0, -10, f'{class_label[y_pred]}: {confidence:.2f}%', size=20, color='blue')  # 예측된 클래스와 확률을 그림 위에 텍스트로 표시
        plt.xticks([])  
        plt.yticks([])  
        plt.show()  
    # 최종 정확도 계산 및 출력
    accuracy = total_correct / total_images if total_images > 0 else 0
    print(f"Accuracy: {accuracy:.4f}")

# 데이터 폴더 내의 이미지 파일을 불러와서 테스트
load_test_images(test_folder)